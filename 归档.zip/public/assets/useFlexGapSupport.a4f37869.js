import{s as a,M as r,aK as t}from"./index.3d111c3c.js";var u=function(){var e=a(!1);return r(function(){e.value=t()}),e};export{u};

import{u,dC as l}from"./index.3d111c3c.js";const{uploadUrl:p=""}=u();function a(o,t){return l.uploadFile({url:p,onUploadProgress:t},o)}export{a as u};

import{R as o,C as r}from"./Col.58addaac.js";import{aq as a}from"./index.3d111c3c.js";var l=a(o),m=a(r);export{m as C,l as R};

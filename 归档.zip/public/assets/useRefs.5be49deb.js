import{s as n,co as a}from"./index.3d111c3c.js";var t=function(){var e=n(new Map),r=function(s){return function(f){e.value.set(s,f)}};return a(function(){e.value=new Map}),[r,e]},c=t;export{c as u};

import{dC as e}from"./index.3d111c3c.js";const s=t=>e.get({url:"/select/getDemoOptions",params:t}),i=t=>e.get({url:"/tree/getDemoOptions",params:t});export{s as o,i as t};

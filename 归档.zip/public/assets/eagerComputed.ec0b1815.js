import{ad as t,K as r}from"./index.3d111c3c.js";function o(a){var e=t();return r(function(){e.value=a()},{flush:"sync"}),e}export{o as e};

import{dC as t}from"./index.3d111c3c.js";const e=()=>t.get({url:"/account/getAccountInfo"}),n=()=>t.post({url:"/user/tokenExpired"});export{e as a,n as t};

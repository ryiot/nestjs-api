import{dC as t}from"./index.3d111c3c.js";const r=e=>t.get({url:"/table/getDemoList",params:e,headers:{ignoreCancelToken:!0}});export{r as d};

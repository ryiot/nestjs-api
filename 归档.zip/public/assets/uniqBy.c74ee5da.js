import{b as n}from"./_baseIteratee.3b7020fd.js";import{cn as o}from"./index.3d111c3c.js";function m(e,t){return e&&e.length?o(e,n(t)):[]}export{m as u};
